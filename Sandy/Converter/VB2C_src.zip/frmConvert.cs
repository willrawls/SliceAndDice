using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using System.Data;

namespace VB2C
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmConvert : System.Windows.Forms.Form
	{
    private System.Windows.Forms.TextBox txtVB6;
    private System.Windows.Forms.Button cmdLoad;
    private System.Windows.Forms.Button cmdConvert;
    private System.Windows.Forms.Button cmdExit;
    private System.Windows.Forms.TextBox txtCSharp;
    private System.Windows.Forms.Label label;
    private System.Windows.Forms.TextBox txtOutPath;
    private System.Windows.Forms.Label label1;
    private System.ComponentModel.IContainer components = null;
	  
		public frmConvert()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
					
		private void InitializeComponent() {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmConvert));
      this.cmdExit = new System.Windows.Forms.Button();
      this.label = new System.Windows.Forms.Label();
      this.txtCSharp = new System.Windows.Forms.TextBox();
      this.cmdConvert = new System.Windows.Forms.Button();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.txtVB6 = new System.Windows.Forms.TextBox();
      this.txtOutPath = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
      this.cmdExit.BackColor = System.Drawing.SystemColors.ControlLight;
      this.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
      this.cmdExit.ForeColor = System.Drawing.SystemColors.ControlText;
      this.cmdExit.Location = new System.Drawing.Point(616, 520);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(80, 40);
      this.cmdExit.TabIndex = 0;
      this.cmdExit.Text = "Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // label
      // 
      this.label.Location = new System.Drawing.Point(40, 16);
      this.label.Name = "label";
      this.label.Size = new System.Drawing.Size(128, 24);
      this.label.TabIndex = 0;
      this.label.Text = "label";
      // 
      // txtCSharp
      // 
      this.txtCSharp.AcceptsReturn = true;
      this.txtCSharp.AcceptsTab = true;
      this.txtCSharp.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.txtCSharp.AutoSize = false;
      this.txtCSharp.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtCSharp.Location = new System.Drawing.Point(8, 264);
      this.txtCSharp.MaxLength = 327670;
      this.txtCSharp.Multiline = true;
      this.txtCSharp.Name = "txtCSharp";
      this.txtCSharp.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtCSharp.Size = new System.Drawing.Size(688, 248);
      this.txtCSharp.TabIndex = 3;
      this.txtCSharp.Text = "";
      this.txtCSharp.WordWrap = false;
      // 
      // cmdConvert
      // 
      this.cmdConvert.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
      this.cmdConvert.Location = new System.Drawing.Point(100, 520);
      this.cmdConvert.Name = "cmdConvert";
      this.cmdConvert.Size = new System.Drawing.Size(80, 40);
      this.cmdConvert.TabIndex = 6;
      this.cmdConvert.Text = "Convert";
      this.cmdConvert.Click += new System.EventHandler(this.cmdConvert_Click);
      // 
      // cmdLoad
      // 
      this.cmdLoad.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
      this.cmdLoad.Location = new System.Drawing.Point(8, 520);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(80, 40);
      this.cmdLoad.TabIndex = 4;
      this.cmdLoad.Text = "Load";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // txtVB6
      // 
      this.txtVB6.AcceptsReturn = true;
      this.txtVB6.AcceptsTab = true;
      this.txtVB6.Anchor = System.Windows.Forms.AnchorStyles.None;
      this.txtVB6.AutoSize = false;
      this.txtVB6.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtVB6.Location = new System.Drawing.Point(8, 8);
      this.txtVB6.MaxLength = 327670;
      this.txtVB6.Multiline = true;
      this.txtVB6.Name = "txtVB6";
      this.txtVB6.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtVB6.Size = new System.Drawing.Size(688, 248);
      this.txtVB6.TabIndex = 2;
      this.txtVB6.Text = "";
      this.txtVB6.WordWrap = false;
      // 
      // txtOutPath
      // 
      this.txtOutPath.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.txtOutPath.Location = new System.Drawing.Point(255, 530);
      this.txtOutPath.Name = "txtOutPath";
      this.txtOutPath.Size = new System.Drawing.Size(220, 20);
      this.txtOutPath.TabIndex = 7;
      this.txtOutPath.Text = "";
      // 
      // label1
      // 
      this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(190, 530);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(47, 13);
      this.label1.TabIndex = 8;
      this.label1.Text = "Out path";
      // 
      // frmConvert
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cmdExit;
      this.ClientSize = new System.Drawing.Size(704, 565);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.label1,
                                                                  this.txtOutPath,
                                                                  this.cmdConvert,
                                                                  this.cmdLoad,
                                                                  this.txtCSharp,
                                                                  this.txtVB6,
                                                                  this.cmdExit});
      this.HelpButton = true;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MinimumSize = new System.Drawing.Size(712, 592);
      this.Name = "frmConvert";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Convert VB6 to C#";
      this.Resize += new System.EventHandler(this.frmConvert_Resize);
      this.Closing += new System.ComponentModel.CancelEventHandler(this.frmConvert_Closing);
      this.Load += new System.EventHandler(this.frmConvert_Load);
      this.ResumeLayout(false);

    }
		#endregion

    private string mFileName = null;
    private string mOutPath = null;

    private void cmdExit_Click(object sender, System.EventArgs e)
    {
      Close();
    }

    private void cmdLoad_Click(object sender, System.EventArgs e)
    {
      mFileName = FileOpen();
      if (mFileName != null)
      {
        // show content of file
        StreamReader Reader = System.IO.File.OpenText(mFileName);	
        txtVB6.Text = Reader.ReadToEnd();
        Reader.Close();
      }
    }

    private string FileOpen()
    {
      string sFilter = "VB6 form (*.frm)|*.frm|VB6 module (*.bas)|*.bas|VB6 class (*.cls)|*.cls|All files (*.*)|*.*" ;	
      string sResult = null;

      OpenFileDialog oDialog = new OpenFileDialog();		
      oDialog.Filter = sFilter;
      if(oDialog.ShowDialog() != DialogResult.Cancel)	
      {		
        sResult = oDialog.FileName;
      }	
      return sResult;
    }

    private void frmConvert_Resize(object sender, System.EventArgs e)
    {
    //-16
      txtVB6.Top = 8;
      txtVB6.Left = 8;
      txtVB6.Height = this.Height / 2 - 60;
      txtVB6.Width = this.Width - 24;
      
      txtCSharp.Left = 8;
      txtCSharp.Top = this.Height / 2 - 16;
      txtCSharp.Height = this.Height / 2 - 60;
      txtCSharp.Width = this.Width - 24;
    }

    private void cmdConvert_Click(object sender, System.EventArgs e)
    {     
       if (mFileName.Trim() != String.Empty)
       {
        // parse file
        ConvertCode ConvertObject = new ConvertCode();
        if ( txtOutPath.Text.Trim() == String.Empty)
        {
          MessageBox.Show("Fill out path !", "", MessageBoxButtons.OK ,MessageBoxIcon.Error);  
          return;
        }
        if ( !Directory.Exists(txtOutPath.Text.Trim()))
        {
          MessageBox.Show("Out path not exists !", "", MessageBoxButtons.OK ,MessageBoxIcon.Error);  
          return;
        }

        mOutPath = txtOutPath.Text;
        if (mOutPath.Substring(mOutPath.Length - 1, 1) != @"\")
        {
          mOutPath = mOutPath + @"\";
        }		
        ConvertObject.ParseFile(mFileName, mOutPath);

        // show result
        txtCSharp.Text = ConvertObject.OutSourceCode;
       }
    }

    private void frmConvert_Load(object sender, System.EventArgs e)
    {
      txtOutPath.Text = App.Config.ReadString(App.CONFIG_SETTING, App.CONFIG_OUT_PATH, "");
    }

    private void frmConvert_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      App.Config.WriteString(App.CONFIG_SETTING, App.CONFIG_OUT_PATH, txtOutPath.Text);
    }

//    private string FileSave()
//    {
//      string sFilter = "C# Files (*.cs)|*.cs" ;	
//      string sResult = null;
//
//      SaveFileDialog oDialog = new SaveFileDialog();		
//      oDialog.Filter = sFilter;
//      if(oDialog.ShowDialog() != DialogResult.Cancel)	
//      {		
//        sResult = oDialog.FileName;
//      }	
//      return sResult;
//    }


	}
}
